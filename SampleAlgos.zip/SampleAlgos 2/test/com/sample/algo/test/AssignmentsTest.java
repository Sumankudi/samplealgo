package com.sample.algo.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.sample.algorithms.Assignments;

public class AssignmentsTest {
	List<Integer> listOne = null;
	List<Integer> listTwo = null;

	@Before
	public void setUp() {
		listOne = new ArrayList<Integer>();
		listOne.add(1);
		listOne.add(2);
		listOne.add(3);
		listOne.add(4);
		listOne.add(5);

		listTwo = new ArrayList<Integer>();
		listTwo.add(6);
		listTwo.add(7);
		listTwo.add(8);
		listTwo.add(9);
		listTwo.add(10);
		listTwo.add(11);
		listTwo.add(12);
		listTwo.add(11);
		listTwo.add(8);
	}

	@Test
	public void filterRangeTest() {
		assertEquals(5, new Assignments().filterRange(listTwo, 8, 11).size());
	}

	@Test
	public void alternateListTest() {
		assertEquals(12, new Assignments().alternate(listOne, listTwo).size());
	}
}
