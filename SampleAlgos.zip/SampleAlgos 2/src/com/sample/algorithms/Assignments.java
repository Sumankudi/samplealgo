/**
 * 
 */
package com.sample.algorithms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author skudikala
 *
 */
public class Assignments {

	public List<Integer> filterRange(List<Integer> list, int min, int max) {
		
		List<Integer> result = list.stream().filter(x-> x!=min && x != max).collect(Collectors.toList());
		System.out.println("filtered resuts : "+result);
		return result;
	}

	public List<Integer> alternate(List<Integer> listOne, List<Integer> listTwo) {
		List<Integer> alternates = new ArrayList<Integer>();
		Iterator<Integer> itrOne = listOne.iterator();
		Iterator<Integer> itrTwo = listTwo.iterator();

		while (itrOne.hasNext() || itrTwo.hasNext()) {
			if (itrOne.hasNext())
				alternates.add(itrOne.next());
			if (itrTwo.hasNext())
				alternates.add(itrTwo.next());
		}

		System.out.println("alternate list : "+alternates);
		return alternates;
	}

//	public static void main(String[] args) {
//		
//
//		//new Assignments().alternate(listOne, listTwo);
//		
//		new Assignments().filterRange(listOne, 2, 7);
//	}
}
